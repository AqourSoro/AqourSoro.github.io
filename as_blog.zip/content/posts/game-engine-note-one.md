---
title: "Game Engine notes"
date: 2024-08-10
draft: true
summary: "The first post of notes in regrad to Game Engine Learning"
tags:
  - notes
---
Game Engine in modern world, is a complex and highly designed tool for developing video games.
